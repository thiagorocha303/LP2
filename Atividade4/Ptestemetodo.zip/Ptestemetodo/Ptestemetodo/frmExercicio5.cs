﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodo
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if (!int.TryParse(txtNumero1.Text, out numero1) || (numero1 < 0))
            {
                MessageBox.Show("n°1 inválido");
                txtNumero1.Focus();
            }
            else if (!int.TryParse(txtNumero2.Text, out numero2) || (numero2 < 0))
            {
                MessageBox.Show("n°2 inválido");
                txtNumero2.Focus();
            }
            else if (numero1 > numero2)
            {
                MessageBox.Show("n°1 é menor que n°2");
                txtNumero1.Focus();
            }
            else
            {
                Random objR = new Random();
                int sorteado = objR.Next(numero1, numero2);
                MessageBox.Show(sorteado.ToString());
            }
        }
    }
}
