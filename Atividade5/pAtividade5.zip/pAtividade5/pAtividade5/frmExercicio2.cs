﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade5
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double num, h = 0;

            if (!double.TryParse(txtN.Text, out num) || (num < 0)) 
            {
                MessageBox.Show("Número inválido");
                txtN.Clear();
                txtN.Focus();
            
            }
            else
            {
                for (int i = 1; i <= num; i++) 
                {
                    h += 1.0 / i;
                }
                MessageBox.Show($"O número h é {h}");
            }
        }
    }
}
