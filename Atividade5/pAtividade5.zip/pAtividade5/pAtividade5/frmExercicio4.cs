﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade5
{
    public partial class frmExercicio4 : Form
    {
        
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double valProducao, valSalario, valGratificacao;

            bool ehNumProducao = double.TryParse(txtProducao.Text, out valProducao);
            bool ehNumSalario = double.TryParse(txtSalario.Text, out valSalario);
            bool ehNumGratificacao = double.TryParse(txtGratificacao.Text, out valGratificacao);

            if (!ehNumProducao || valProducao < 0) 
            { 
                MessageBox.Show("Produção inválida!");
                txtProducao.Focus();
            }
            else if (!ehNumSalario || valSalario <=0) 
            { 
                MessageBox.Show("Salário inválido!");
                txtSalario.Focus();
            }
            else if (!ehNumGratificacao || valGratificacao < 0) 
            { 
                MessageBox.Show("Gratificação inválida!");
                txtGratificacao.Focus();
            }
            else
            {
                double B = 0, C = 0, D = 0;
                double salBruto;

                if (valProducao >= 150)
                {
                    B = 1;
                    C = 1;
                    D = 1;
                }
                else if (valProducao >= 120 && valProducao < 150)
                {
                    B = 1;
                    C = 1;
                }
                else if (valProducao >= 100 && valProducao < 120)
                {
                    B = 1;
                }

                salBruto = valSalario + valSalario * (0.05 * B + 0.1 * C + 0.1 * D) + valGratificacao;

                if (salBruto > 7000) 
                { 
                    if (D == 1 && valGratificacao > 0)
                    {
                        MessageBox.Show($"O sálario bruto é R${salBruto}");
                    }
                    else
                    {
                        salBruto = 7000;
                        MessageBox.Show($"O sálario bruto é R${salBruto}");
                    }
                }
                else
                {
                    MessageBox.Show($"O sálario bruto é R${salBruto}");
                }

            }
        }


        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtGratificacao.Clear();
            txtSalario.Clear();
            txtProducao.Clear();
            txtNome.Clear();
            txtMatricula.Clear();
        }
    }
}
