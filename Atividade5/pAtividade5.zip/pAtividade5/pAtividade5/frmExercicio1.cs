﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int qtdBranco = 0;

            while (posicao < rchtxtFrase.Text.Length)
            {
                if (rchtxtFrase.Text[posicao] == ' ')
                {
                    qtdBranco++;
                }
                posicao++;
            }

            MessageBox.Show($"A quantidade de espaços em branco é: {qtdBranco}");
        }

        private void btnQtdR_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int qtdR = 0;

            for ( posicao = 0; posicao < rchtxtFrase.Text.Length; posicao++)
            {
                if (rchtxtFrase.Text[posicao] == 'r' || rchtxtFrase.Text[posicao] == 'R')
                {
                    qtdR++;
                }
            }

            MessageBox.Show($"A quantidade de R é: {qtdR}");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int qtdPares = 0;
            string frase = rchtxtFrase.Text.ToLower();

            if (frase.Length > 1)
            {
                do
                {
                    if (frase[posicao] == frase[posicao + 1])
                    {
                        qtdPares++;
                    }

                    posicao++;

                } while (posicao < frase.Length - 1);
            }

            MessageBox.Show($"A quantidade de pares com a mesma letra é: {qtdPares}");
        }
    }
}
