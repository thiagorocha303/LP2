﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int i = 0; 
            string strOriginal = txtTexto.Text.ToLower();

            if (txtTexto.Text.Length > 50) 
            {
                MessageBox.Show("Texto maior que 50 caracteres");
                txtTexto.Focus();
            }
            else
            {
                string strSemEspaco = strOriginal.Replace(" ", "");

                char[] invertido = strSemEspaco.ToCharArray();
                Array.Reverse(invertido);

                string strInvertida =new string(invertido);

                if (string.Compare(strSemEspaco, strInvertida) == 0)
                {
                    MessageBox.Show("É um palíndromo");
                }
                else 
                {
                    MessageBox.Show("Não é um palíndromo");
                }
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtTexto.Clear();
        }
    }
}
