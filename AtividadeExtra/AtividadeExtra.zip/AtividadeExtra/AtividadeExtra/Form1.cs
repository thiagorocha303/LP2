﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace AtividadeExtra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[7,5];
            string[] diaSemana = { "Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado" };
            double[] TotalporDia = new double[7];
            double TotalGeral = 0;

            for (int dia = 0; dia < 7; dia++)
            {
                TotalporDia[dia] = 0;
                for(int produto = 0; produto < 5; produto++)
                {
                    string aux = "";
                    aux = Interaction.InputBox($"Digite o valor do produto {produto + 1} de {diaSemana[dia]}: ", "Entrada de dados:");
                    
                    if (aux == "")
                        return;
                    
                    if (!double.TryParse(aux, out matriz[dia, produto]) || matriz[dia, produto] < 0)
                    {
                        MessageBox.Show("Valor inválido!");
                        produto--;
                    }
                    else
                    {
                        TotalporDia[dia] += matriz[dia, produto];
                    }
                }
                TotalGeral += TotalporDia[dia];
                lstbxValores.Items.Add($"{diaSemana[dia]}: R${TotalporDia[dia].ToString("F2")}");
            }

            lstbxValores.Items.Add("----------------------------");
            lstbxValores.Items.Add($"Total Geral: R${TotalGeral.ToString("F2")}");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxValores.Items.Clear();
        }
    }
}
