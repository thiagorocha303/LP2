﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();

            double[,] matriz = new double[2,3];
            double[] media = new double[2];
            double mediaGeral = 0;

            int aluno;
            int professor;

            for ( aluno = 0; aluno < 2; aluno++)
            {
                for ( professor = 0; professor < 3; professor++)
                {
                    string aux = "";
                    aux = Interaction.InputBox($"Professor{professor + 1} digite a nota do aluno{aluno + 1}: ", "Entrada de dados");

                    if (aux == "")
                        return;

                    if(!double.TryParse(aux, out matriz[aluno, professor]) || matriz[aluno, professor] < 0 || matriz[aluno, professor] > 10)
                    {
                        MessageBox.Show("Nota inválida");
                        professor--;
                    }
                    else
                    {
                        media[aluno] += matriz[aluno, professor];
                    }
                }
                mediaGeral += media[aluno];
                media[aluno] = media[aluno] / professor;
                lstbxResultado.Items.Add($"Aluno{aluno + 1}. Nota Professor1: {matriz[aluno, 0]:F2}. Nota Professor2: {matriz[aluno, 1]:F2}. Nota Professor3: {matriz[aluno, 2]:F2}. Média: {media[aluno]:F2}");
            }

            mediaGeral = mediaGeral / 6;

            lstbxResultado.Items.Add("========================");
            lstbxResultado.Items.Add($"Média Geral dos Alunos: {mediaGeral:F2}");
                      
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }
    }
}
